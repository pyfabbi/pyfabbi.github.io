import sys
from flask import Flask, request, render_template

def get_similarity(text1, text2):
    wordset1 = set(text1.lower().split(' '))
    wordset2 = set(text2.lower().split(' '))
    inter_set = wordset1.intersection(wordset2)
    union_set = wordset1.union(wordset2)
    return len(inter_set)/len(union_set)

f = open('articles.txt', encoding='utf-8')
articles = f.read().splitlines()
f.close()

app = Flask(__name__)

@app.route('/')
def mainPage():
    return render_template('index.html')

@app.route('/find_articles', methods = ['POST'])
def findArticles():
    content = request.form['content']
    
    scores = [[get_similarity(content, article), i] for i, article in enumerate(articles)]

    scores = sorted(scores, reverse=True)
    
    top_articles = [articles[i] for (_,i) in scores[:5]]
    return render_template("result.html", content=content, top_articles=top_articles)

app.run(debug=True)