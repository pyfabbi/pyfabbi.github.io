function get(url, params) {
	  
  if(params) {
	url += '?' + this.serialize(params);
  }
  
  return fetch(url).then(response => response.json());
}

function post(url, params) {
  
  return fetch(url, {
		 method : 'POST',
		 headers : {'Content-Type': 'application/json'},
		 body : JSON.stringify(params)
	  }).then(response => response.json());
}