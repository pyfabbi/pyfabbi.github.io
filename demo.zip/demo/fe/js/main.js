Vue.mixin( {  
  methods: {
	getParam : function(name){
		if(name=(new RegExp('[?&]'+encodeURIComponent(name)+'=([^&]*)')).exec(location.search))
			return decodeURIComponent(name[1]);
	},
	
	serialize : function(obj) {
	  var str = [];
	  for (var p in obj)
		if (obj.hasOwnProperty(p)) {
		  str.push(encodeURIComponent(p) + "=" + encodeURIComponent(obj[p]));
		}
	  return str.join("&");
	},

    get : function(url, params) {
	  	  
	  if(params) {
		url += '?' + this.serialize(params);
	  }
	  
	  return fetch(url).then(response => response.json());
	},
	
	post : function(url, params) {
	  
	  return fetch(url, {
			 method : 'POST',
			 headers : {'Content-Type': 'application/json'},
			 body : JSON.stringify(params)
		  }).then(response => response.json());
	},
  }
});